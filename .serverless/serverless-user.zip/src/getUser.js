import { PrismaClient } from '@prisma/client';

const prismaClientDatabase = new PrismaClient();

export async function handler (event) {
    try {
        console.log('Antes de chamar findMany');

        const result = await prismaClientDatabase.user.findMany();

        console.log('Depois de chamar findMany');

        return {
            statusCode: 200,
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ result, input: event })
        };
    } catch (error) {
        console.error(error)
        return {
          statusCode: 500,
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ error, input: event }),
        }
      }
}